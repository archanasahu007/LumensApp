package com.flipkart.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import HCL.Hackaton_Demo.BaseClass;

public class LoginPOM extends BaseClass {
	
	public LoginPOM() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//*[@class='_2IX_2- VJZDxU']")
	private WebElement emailtxtbox;
	
	@FindBy(xpath = "//*[@type='password']")
	private WebElement passtxtbox;
	
	@FindBy(xpath = "//*[@class='_2KpZ6l _2HKlqd _3AWRsL']")
	private WebElement loginbtn;
	
	@FindBy(xpath = "//*[text()='Tamil']")
	private WebElement usernameTxt;
	
	@FindBy(xpath = "//*[contains(text(),'incorrect')]")
	private WebElement incorrect_credentials;
	
	@FindBy(xpath = "//*[text()='Electronics']")
	private WebElement electronicsbtn;
	
	public WebElement getElectronicsbtn() {
		return electronicsbtn;
	}

	public WebElement getIncorrect_credentials() {
		return incorrect_credentials;
	}

	public WebElement getUsernameTxt() {
		return usernameTxt;
	}

	public WebElement getLoginbtn() {
		return loginbtn;
	}

	public WebElement getEmailtxtbox() {
		return emailtxtbox;
	}

	public WebElement getPasstxtbox() {
		return passtxtbox;
	}


}
