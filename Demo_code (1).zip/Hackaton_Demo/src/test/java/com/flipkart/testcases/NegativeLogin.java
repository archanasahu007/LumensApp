package com.flipkart.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.flipkart.pageobjects.LoginPOM;

import HCL.Hackaton_Demo.BaseClass;

public class NegativeLogin extends BaseClass {
	/*
	 * @Test public void N_Login() throws Exception { launchBrowser();
	 * driver.get(prop.getProperty("url")); max(); String text
	 * =driver.findElement(By.xpath("//*[@jsselect='heading']")).getText();
	 * if(text.equals("This site can’t be reached")){
	 * System.out.println("The entered url is incorrect");}
	 * 
	 * //Wrong url code String wurl=prop.getProperty("wrongurl");
	 * if(wurl.equals("https://www.flipcart.com/")) {
	 * driver.get(prop.getProperty("wurl")); String text =
	 * driver.findElement(By.xpath("//*[@jsselect='heading']")).getText();
	 * if(text.equals("This site can’t be reached")){
	 * System.out.println("The entered url is incorrect");} }
	 * 
	 * 
	 * }
	 */
	@BeforeTest
	public void bTest() throws IOException {

		launchBrowser();
		driver.get(prop.getProperty("url"));
		max();
	}

	@Test
	public void login() {
		LoginPOM l = new LoginPOM();
		fill(l.getEmailtxtbox(), "8438265694");
		fill(l.getPasstxtbox(), "Tamil@0303");
		l.getLoginbtn().click();
		String errorMessage = l.getIncorrect_credentials().getText();
		if (errorMessage.equals("Your username or password is incorrect")) {
			System.out.println("Enter usename/password is incorrect");
		}
	}
}
