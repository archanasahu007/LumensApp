package com.flipkart.testcases;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.flipkart.pageobjects.LoginPOM;

import HCL.Hackaton_Demo.BaseClass;

public class Login extends BaseClass  {
	
	public String path ="C:\\Users\\admin\\Tamil_wrkspc\\Hackaton_Demo\\ScreenShots";

	@BeforeTest
	public void bTest() throws IOException {

		
		launchBrowser();
		driver.get(prop.getProperty("url"));
		max();
	}

	@Test
	public void login() throws Exception {
		LoginPOM l = new LoginPOM();
		String user = prop.getProperty("username");
		String pass = prop.getProperty("password");
		fill(l.getEmailtxtbox(), user);
		fill(l.getPasstxtbox(), pass);
		/*
		 * l.getEmailtxtbox().sendKeys("8438265694");
		 * l.getPasstxtbox().sendKeys("Tamil@03");
		 */
		l.getLoginbtn().click();
		// Homepage UI Verification
		String title = driver.getTitle();
		if (title.contains("Online Shopping")) {
			System.out.println("Homepage Verified Successfully");
			screenShot(path +"\\Homepage_before_login.jpeg");
		} else {
			System.out.println("User not in homepage");
		}

		// Username Verification
		String username = l.getUsernameTxt().getText();
		if (username.equals("Tamil")) {
			System.out.println("Username verified successfully and Usename is "+ username);
			screenShot(path +"\\Homepage_After_login.jpeg");
		} else {
			System.out.println("Entered username is incorrect");
		}
		// Navigate to electronics screen
		l.getElectronicsbtn().click();
		String title2 = driver.getTitle();
		if (title2.contains("Electronics")) {
			System.out.println("User is in Electronics Window...Keep Shopping...");
			screenShot(path +"\\Electronics_Page.jpeg");
		}

	}

	/*
	 * @AfterTest public void aTest() { driver.close(); }
	 */

}
